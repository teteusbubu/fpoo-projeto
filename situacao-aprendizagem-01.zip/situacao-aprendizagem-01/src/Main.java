import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		
		
		Scanner scanner = new Scanner(System.in);
		DadosPessoais objdadosPessoais = new DadosPessoais();
		DadosContato objdadoscontato = new DadosContato();
		DadosEndereco objdadosendereco = new DadosEndereco();
		
		System.out.println("####---- BEM VINDO AO PROGRAMA  ----####");
		
		System.out.println("INFORME O NOME DO ALUNO:");
		objdadosPessoais.setNome(scanner.next());

		System.out.println("INFORME O SOBRENOME DO ALUNO:");
		objdadosPessoais.setSobrenome(scanner.next());
		
		System.out.println("INFORME A DATA DE NASCIMENTO DO ALUNO:");
		objdadosPessoais.setDatanascimento(scanner.next());
		
		System.out.println("INFORME O GENERO DO ALUNO:");
		objdadosPessoais.setGenero(scanner.next());

		
		System.out.println("INFORME O EMAIL:");
		objdadoscontato.setEmail(scanner.next());
		
		System.out.println("INFORME O TELEFONE:");
		objdadoscontato.setTelefone(scanner.next());
		
		System.out.println("INFORME O CEP:");
		objdadosendereco.setCep(scanner.next());
		
		System.out.println("INFORME O lOGADOURO:");
		objdadosendereco.setLagradouro(scanner.next());
		
		System.out.println("INFORME O N�MERO DA CASA:");
		objdadosendereco.setNumero(scanner.next());
		
		System.out.println("INFORME O BAIRRO:");
		objdadosendereco.setBairro(scanner.next());
		
		System.out.println("INFORME A CIDADE:");
		objdadosendereco.setCidade(scanner.next());
		
		System.out.println("INFORME O ESTADO:");
		objdadosendereco.setEstado(scanner.next());

	}

}
